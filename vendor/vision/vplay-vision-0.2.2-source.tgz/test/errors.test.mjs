import test from 'node:test';
import assert from 'node:assert/strict';
import {
  ERROR_CATEGORIES,
  classifyHttpStatus,
  classifyNetworkError,
  classifyOutput,
  shouldRetry,
} from '../src/errors.mjs';

test('401/403/402 are not retryable and are classified distinctly', () => {
  const auth = classifyHttpStatus({ status: 401, payload: { error: { message: 'bad key' } } });
  const permission = classifyHttpStatus({ status: 403, payload: { error: { message: 'no model access' } } });
  const quota = classifyHttpStatus({ status: 402, payload: { error: { message: 'arrears' } } });
  assert.equal(auth.category, ERROR_CATEGORIES.AUTH);
  assert.equal(auth.retryable, false);
  assert.equal(permission.category, ERROR_CATEGORIES.PERMISSION);
  assert.equal(permission.retryable, false);
  assert.equal(quota.category, ERROR_CATEGORIES.QUOTA);
  assert.equal(quota.retryable, false);
});

test('429 distinguishes quota from rate limiting and is not retried by default', () => {
  const quota = classifyHttpStatus({ status: 429, payload: { error: { code: 'insufficient_quota', message: 'quota exceeded' } } });
  const rate = classifyHttpStatus({ status: 429, payload: { error: { message: 'too many requests' } } });
  assert.equal(quota.category, ERROR_CATEGORIES.QUOTA);
  assert.equal(rate.category, ERROR_CATEGORIES.RATE_LIMIT);
  assert.equal(quota.retryable, false);
  assert.equal(rate.retryable, false);
});

test('5xx and network are retryable; timeout is not', () => {
  const server = classifyHttpStatus({ status: 503, payload: { error: { message: 'busy' } } });
  const network = classifyNetworkError(new Error('ECONNRESET'));
  const timeout = classifyNetworkError(Object.assign(new Error('aborted'), { name: 'TimeoutError' }));
  assert.equal(server.category, ERROR_CATEGORIES.SERVER);
  assert.equal(server.retryable, true);
  assert.equal(network.category, ERROR_CATEGORIES.NETWORK);
  assert.equal(network.retryable, true);
  assert.equal(timeout.category, ERROR_CATEGORIES.TIMEOUT);
  assert.equal(timeout.retryable, false);
});

test('finish_reason=length is output_truncated, not invalid_json', () => {
  const error = classifyOutput({ finishReason: 'length', rawContent: '{"summary":' });
  assert.equal(error.category, ERROR_CATEGORIES.OUTPUT_TRUNCATED);
  assert.equal(error.retryable, false);
});

test('schema and invalid JSON are distinct', () => {
  const schema = classifyOutput({ schemaErrors: ['defects must be an array'] });
  const invalid = classifyOutput({ error: new Error('unexpected end') });
  assert.equal(schema.category, ERROR_CATEGORIES.SCHEMA);
  assert.equal(invalid.category, ERROR_CATEGORIES.INVALID_JSON);
});

test('retry policy honors 5xx and never auth/permission/quota', () => {
  const server = classifyHttpStatus({ status: 500 });
  const auth = classifyHttpStatus({ status: 401 });
  const permission = classifyHttpStatus({ status: 403 });
  const quota = classifyHttpStatus({ status: 429, payload: { error: { message: 'quota exceeded' } } });
  assert.equal(shouldRetry(server, {}), true);
  assert.equal(shouldRetry(server, { retryOn5xx: false }), false);
  assert.equal(shouldRetry(auth, {}), false);
  assert.equal(shouldRetry(permission, {}), false);
  assert.equal(shouldRetry(quota, {}), false);
});
