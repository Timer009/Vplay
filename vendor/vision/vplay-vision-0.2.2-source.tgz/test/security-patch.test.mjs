import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { validatePatchPlan, validateCss, validateHtmlFragment } from '../src/patch/validator.mjs';
import { tempDir } from './helpers.mjs';

const HTML = `<!doctype html>
<html><head><style>
#cover { display: block; color: #fff; }
</style></head><body>
<div id="cover">STATUS</div>
<div id="safe" class="box">ok</div>
<script>window.game={fuel:120};</script>
</body></html>`;

async function workspace() {
  const dir = await tempDir('e05-patch-');
  await fs.writeFile(path.join(dir, 'index.html'), HTML, 'utf8');
  return dir;
}

function plan(oldString, newString, file = 'index.html') {
  return {
    diagnosis: 'test',
    patches: [{ file, old_string: oldString, new_string: newString, reason: 'test' }],
    verification: ['test'],
  };
}

test('allows overlay removal and CSS visibility changes', async () => {
  const dir = await workspace();
  try {
    const removal = validatePatchPlan({
      plan: plan('<div id="cover">STATUS</div>', ''),
      root: dir,
      allowedFiles: ['index.html'],
    });
    assert.equal(removal.ok, true, removal.errors.join('; '));

    const css = validatePatchPlan({
      plan: plan('#cover { display: block; color: #fff; }', '#cover { display: none; }'),
      root: dir,
      allowedFiles: ['index.html'],
    });
    assert.equal(css.ok, true, css.errors.join('; '));

    const safeHtml = validatePatchPlan({
      plan: plan('<div id="safe" class="box">ok</div>', '<div id="safe" class="hint">ok</div>'),
      root: dir,
      allowedFiles: ['index.html'],
    });
    assert.equal(safeHtml.ok, true, safeHtml.errors.join('; '));
  } finally {
    await fs.rm(dir, { recursive: true, force: true });
  }
});

const BYPASSES = [
  ['protocol-relative img', '<img src=//evil.example/x>'],
  ['css import', '<style>@import \'//evil.example/x.css\';</style>'],
  ['meta refresh', '<meta http-equiv=refresh content="0;url=//evil.example">'],
  ['iframe', '<iframe src=//evil.example>'],
  ['object', '<object data=//evil.example>'],
  ['srcset', '<img srcset=//evil.example/x 2x>'],
  ['anchor', '<a href=//evil.example>go</a>'],
  ['form', '<form action=//evil.example><input name=x></form>'],
  ['link preload', '<link rel=preload href=//evil.example/x>'],
  ['script', '<script>alert(1)</script>'],
  ['event handler', '<div onclick="alert(1)">x</div>'],
  ['svg onload', '<svg onload="alert(1)"></svg>'],
  ['srcdoc', '<iframe srcdoc="<script>alert(1)</script>"></iframe>'],
  ['style url', '<div style="background:url(//evil.example/x)">x</div>'],
  ['style expression', '<div style="width:expression(alert(1))">x</div>'],
  ['data javascript', '<div data-x="javascript:alert(1)">x</div>'],
  ['behavior', '<div style="behavior:url(#x)">x</div>'],
  ['image-set', '<div style="background:image-set(url(//evil))">x</div>'],
  ['backtick', '<div style="color:red;x:y`">x</div>'],
  ['data html', '<a href="data:text/html,<script>alert(1)</script>">x</a>'],
  ['base', '<base href=//evil.example>'],
  ['entity', '<div title="&#x3c;script&#x3e;">x</div>'],
  ['formaction', '<button formaction=//evil.example>x</button>'],
  ['poster', '<video poster=//evil.example></video>'],
  ['ping', '<a ping=//evil.example>x</a>'],
];

test('all C07-style HTML/CSS bypass payloads are rejected', async () => {
  const dir = await workspace();
  try {
    for (const [name, payload] of BYPASSES) {
      const result = validatePatchPlan({
        plan: plan('<div id="safe" class="box">ok</div>', payload),
        root: dir,
        allowedFiles: ['index.html'],
      });
      assert.equal(result.ok, false, `${name} was accepted: ${payload}`);
      assert.ok(result.errors.length > 0, `${name} has no reason`);
    }
  } finally {
    await fs.rm(dir, { recursive: true, force: true });
  }
});

test('CSS validator rejects external/executable constructs', () => {
  for (const css of [
    '@import "//evil.example/x.css";',
    'body{background:url(//evil.example/x)}',
    'body{width:expression(alert(1))}',
    'body{behavior:url(#x)}',
    'body{-moz-binding:url(#x)}',
    'body{background:image-set(url(//evil))}',
    'body{color:\\75 rl}',
    'body{color:red}/*x*/',
  ]) {
    assert.equal(validateCss(css).ok, false, css);
  }
  assert.equal(validateCss('#cover{display:none;color:#fff}').ok, true);
  assert.equal(validateCss('body{margin:calc(100% - 10px)}').ok, true);
});

test('HTML fragment allowlist rejects unknown tags/URL attributes and allows safe UI', () => {
  assert.equal(validateHtmlFragment('<div class="hint" role="status">ok</div>').ok, true);
  assert.equal(validateHtmlFragment('<img src=//evil>').ok, false);
  assert.equal(validateHtmlFragment('<div style="background:url(//evil)">x</div>').ok, false);
  assert.equal(validateHtmlFragment('<div data-note="safe text">x</div>').ok, true);
});

test('path traversal, dot dirs, JS files and outside allowed files are rejected', async () => {
  const dir = await workspace();
  try {
    for (const [file, allowed] of [
      ['../index.html', ['../index.html']],
      ['.opengame/index.html', ['.opengame/index.html']],
      ['.snapshots/index.html', ['.snapshots/index.html']],
      ['index.js', ['index.js']],
      ['/etc/passwd', ['/etc/passwd']],
      ['other.html', ['index.html']],
    ]) {
      const result = validatePatchPlan({
        plan: plan('<div id="safe" class="box">ok</div>', '', file),
        root: dir,
        allowedFiles: allowed,
      });
      assert.equal(result.ok, false, file);
    }
  } finally {
    await fs.rm(dir, { recursive: true, force: true });
  }
});

test('symlinked allowed file is rejected', async () => {
  const outside = await tempDir('e05-outside-');
  const dir = await workspace();
  try {
    await fs.writeFile(path.join(outside, 'index.html'), HTML, 'utf8');
    try {
      await fs.symlink(path.join(outside, 'index.html'), path.join(dir, 'linked.html'), 'file');
    } catch (error) {
      if (process.platform === 'win32' && /EPERM|EACCES/.test(error.code || '')) return; // developer mode unavailable
      throw error;
    }
    const result = validatePatchPlan({
      plan: plan('<div id="safe" class="box">ok</div>', '', 'linked.html'),
      root: dir,
      allowedFiles: ['linked.html'],
    });
    assert.equal(result.ok, false);
    assert.ok(result.errors.some((error) => error.includes('symlink')));
  } finally {
    await fs.rm(outside, { recursive: true, force: true });
    await fs.rm(dir, { recursive: true, force: true });
  }
});

test('script edits remain rejected', async () => {
  const dir = await workspace();
  try {
    const result = validatePatchPlan({
      plan: plan('window.game={fuel:120};', 'window.game={fuel:999};'),
      root: dir,
      allowedFiles: ['index.html'],
    });
    assert.equal(result.ok, false);
    assert.ok(result.errors.some((error) => error.includes('<script>')));
  } finally {
    await fs.rm(dir, { recursive: true, force: true });
  }
});
