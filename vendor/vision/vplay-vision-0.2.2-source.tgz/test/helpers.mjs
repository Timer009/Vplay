import fs from 'node:fs';
import fsp from 'node:fs/promises';
import http from 'node:http';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.png': 'image/png',
  '.json': 'application/json; charset=utf-8',
};

export async function startStaticServer(root) {
  const base = path.resolve(root);
  const server = http.createServer(async (req, res) => {
    const url = new URL(req.url, 'http://localhost');
    let rel = decodeURIComponent(url.pathname).replace(/^\/+/, '') || 'index.html';
    if (rel.endsWith('/')) rel += 'index.html';
    const file = path.resolve(base, rel);
    if (!file.startsWith(base + path.sep) && file !== base) {
      res.writeHead(403);
      res.end('forbidden');
      return;
    }
    try {
      const data = await fsp.readFile(file);
      res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream' });
      res.end(data);
    } catch {
      res.writeHead(404);
      res.end('not found');
    }
  });
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const { port } = server.address();
  return { url: `http://127.0.0.1:${port}/`, close: () => new Promise((resolve) => server.close(resolve)) };
}

export async function startStub(handler) {
  const requests = [];
  const server = http.createServer(async (req, res) => {
    let raw = '';
    for await (const chunk of req) raw += chunk.toString();
    let body = null;
    try { body = raw ? JSON.parse(raw) : null; } catch { body = raw; }
    requests.push({ method: req.method, url: req.url, headers: req.headers, body });
    try { await handler(requests[requests.length - 1], res, requests.length); }
    catch (error) { res.writeHead(500); res.end(JSON.stringify({ error: { message: error.message } })); }
  });
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const { port } = server.address();
  return {
    baseUrl: `http://127.0.0.1:${port}/v1`,
    requests,
    close: () => new Promise((resolve) => server.close(resolve)),
  };
}

export function jsonResponse(res, status, payload) {
  res.writeHead(status, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify(payload));
}

export function chatReply(content, { model = 'stub-model', finishReason = 'stop', usage = { prompt_tokens: 10, completion_tokens: 5, total_tokens: 15 } } = {}) {
  return {
    id: 'chatcmpl-stub',
    object: 'chat.completion',
    model,
    choices: [{ index: 0, message: { role: 'assistant', content }, finish_reason: finishReason }],
    usage,
  };
}

export async function tempDir(prefix = 'vplay-vision-') {
  return fsp.mkdtemp(path.join(os.tmpdir(), prefix));
}

export function readFixture(name) {
  return fs.readFileSync(new URL(`./fixtures/${name}`, import.meta.url), 'utf8');
}

/**
 * Locate the optional E02 sample corpus regardless of how deep this package is
 * extracted or installed. Tests that need real E02 images/cases skip when the
 * corpus is absent.
 */
export function findSamples(rel = '') {
  const override = process.env.VPLAY_E02_SAMPLES;
  if (override) {
    const candidate = path.join(override, rel);
    return fs.existsSync(candidate) ? candidate : null;
  }
  let dir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
  for (let i = 0; i < 10; i += 1) {
    const candidate = path.join(dir, 'e02', 'samples', rel);
    if (fs.existsSync(candidate)) return candidate;
    const parent = path.dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }
  return null;
}

export function fileExists(file) {
  return fs.existsSync(file);
}
