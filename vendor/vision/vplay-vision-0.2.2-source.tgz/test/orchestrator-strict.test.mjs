import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';

import { runVisionTask } from '../src/index.mjs';
import { tempDir } from './helpers.mjs';

const PLAN = {
  diagnosis: 'safe class',
  patches: [{ file: 'index.html', old_string: '<div id="hud">HUD</div>', new_string: '<div id="hud" class="v">HUD</div>', reason: 'x' }],
  verification: ['hud'],
};

function capture({ ok, assertions, sha }) {
  return {
    ok,
    browserVersion: 'fake',
    durationMs: 1,
    screenshots: [{ viewport: 'pc', path: `/tmp/${sha}.png`, sha256: sha, bytes: 1 }],
    viewports: [{
      viewport: 'pc',
      ok,
      sha256: sha,
      assertions: assertions.map(([id, value, critical = true]) => ({ id, ok: value, critical, detail: {} })),
      diagnostics: { pageErrors: [], console: [], requestFailures: [] },
    }],
  };
}

function gateway() {
  return {
    async analyzeScreenshots() {
      return {
        report: {
          summary: 'fixture',
          defects: [{
            id: 'model-id-varies',
            defect_type: 'ui_occlusion',
            location: { screen: 'pc', description: 'hud', region: null },
            severity: 'major',
            evidence: { screenshots: ['before.png'], observation: 'x' },
            confidence: 0.9,
            recommendation: 'x',
            verification: 'x',
          }],
          limitations: [],
        },
        meta: { model: 'fake', usage: {}, latencyMs: 1, requestId: 'r1' },
      };
    },
    async proposePatchPlan() {
      return { plan: PLAN, meta: { model: 'fake', usage: {}, latencyMs: 1, requestId: 'r2' } };
    },
    summary() { return {}; },
  };
}

async function runCase({ before, after, policy = 'strict-repair', defectAssertionIds = ['hud'], maxRounds = 1 }) {
  const root = await tempDir('e10-strict-');
  await fsp.writeFile(path.join(root, 'index.html'), '<div id="hud">HUD</div>', 'utf8');
  const calls = { rollback: 0, apply: 0, snapshot: 0 };
  const host = {
    async snapshot() { calls.snapshot += 1; return { seq: 7 }; },
    async applyFiles() { calls.apply += 1; },
    async diff() { return { counts: { added: 0, modified: 1, removed: 0 }, files: [{ file: 'index.html' }] }; },
    async rollback() { calls.rollback += 1; return { verified: true, previewReady: true }; },
  };
  const browserRunner = { async runCapture({ scenario }) { return scenario === 'before' ? before : after; } };
  const result = await runVisionTask({
    taskId: 'strict',
    projectId: 'demo',
    root,
    previewUrl: 'http://127.0.0.1:1/',
    adapter: { id: 'fake', viewports: [{ name: 'pc' }] },
    browserRunner,
    gateway: gateway(),
    host,
    mode: 'repair',
    allowedFiles: ['index.html'],
    maxRepairRounds: maxRounds,
    verificationPolicy: policy,
    defectAssertionIds,
    sourceProvider: async () => '<div id="hud">HUD</div>',
    outDir: path.join(root, 'out'),
  });
  return { result, calls };
}

const beforeFail = capture({ ok: false, assertions: [['hud', false]], sha: 'a'.repeat(64) });
const beforePass = capture({ ok: true, assertions: [['hud', true]], sha: 'a'.repeat(64) });
const afterPass = capture({ ok: true, assertions: [['hud', true]], sha: 'b'.repeat(64) });

test('strict-repair: defect assertion before=false after=true -> repair_verified', async () => {
  const { result, calls } = await runCase({ before: beforeFail, after: afterPass });
  assert.equal(result.ok, true);
  assert.equal(result.status, 'repair_verified');
  assert.equal(result.comparison.defect.ok, true);
  assert.equal(result.strictVerification.ok, true);
  assert.equal(result.defect.defectKey, result.comparison.defectKey);
  assert.equal(calls.snapshot, 1);
  assert.equal(calls.apply, 1);
  assert.equal(calls.rollback, 0);
});

test('strict-repair without defect ids -> repair_unconfirmed and rollback', async () => {
  const { result, calls } = await runCase({ before: beforeFail, after: afterPass, defectAssertionIds: [] });
  assert.equal(result.ok, false);
  assert.equal(result.status, 'repair_unconfirmed');
  assert.equal(result.strictVerification.reason, 'no-defect-assertions');
  assert.equal(calls.rollback, 1);
});

test('strict-repair: defect not present before -> repair_unconfirmed', async () => {
  const { result, calls } = await runCase({ before: beforePass, after: afterPass });
  assert.equal(result.ok, false);
  assert.equal(result.status, 'repair_unconfirmed');
  assert.equal(result.comparison.defect.reason, 'defect-not-reproduced-before');
  assert.equal(calls.rollback, 1);
});

test('strict-repair: deleted defect assertion -> repair_unconfirmed', async () => {
  const afterWithoutHud = capture({ ok: true, assertions: [['other', true]], sha: 'b'.repeat(64) });
  const { result, calls } = await runCase({ before: beforeFail, after: afterWithoutHud });
  assert.equal(result.ok, false);
  assert.equal(result.status, 'repair_unconfirmed');
  assert.equal(result.comparison.missingAssertions.length >= 1, true);
  assert.equal(result.strictVerification.reason, 'defect-assertion-missing');
  assert.equal(calls.rollback, 1);
});

test('confirmed: screenshot-only and after-failure stay unconfirmed/failed', async () => {
  const screenshotsOnly = await runCase({ before: beforePass, after: afterPass, policy: 'confirmed', defectAssertionIds: [] });
  assert.equal(screenshotsOnly.result.ok, false);
  assert.equal(screenshotsOnly.result.status, 'repair_unconfirmed');

  const afterFail = capture({ ok: false, assertions: [['hud', false]], sha: 'b'.repeat(64) });
  const failed = await runCase({ before: beforeFail, after: afterFail, policy: 'confirmed', defectAssertionIds: ['hud'] });
  assert.equal(failed.result.ok, false);
  assert.equal(failed.result.status, 'repair_failed');
  assert.equal(failed.calls.rollback, 1);
});

test('after-only keeps the legacy repaired status', async () => {
  const { result } = await runCase({ before: beforeFail, after: afterPass, policy: 'after-only', defectAssertionIds: [] });
  assert.equal(result.ok, true);
  assert.equal(result.status, 'repaired');
});
