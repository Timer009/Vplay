import test from 'node:test';
import assert from 'node:assert/strict';
import { loadConfig, assertModelConfig, redactConfig, VERIFIED_DEFAULTS } from '../src/config.mjs';

test('verified defaults: qwen4-max and deepseek, browser has no key fields', () => {
  const config = loadConfig({});
  assert.equal(config.vision.model, VERIFIED_DEFAULTS.vision.model);
  assert.equal(config.vision.model, 'qwen4-max');
  assert.equal(config.vision.baseUrl, 'https://dashscope.aliyuncs.com/compatible-mode/v1');
  assert.equal(config.text.model, 'deepseek-v4-flash');
  assert.equal(config.text.baseUrl, 'https://api.deepseek.com');
  assert.equal(config.browser.executablePath, null);
  assert.ok(!('apiKey' in config.browser));
});

test('environment overrides model, base URL, timeout, budget, browser', () => {
  const config = loadConfig({
    VPLAY_VISION_MODEL: 'vision-x',
    VPLAY_VISION_BASE_URL: 'https://vision.example/v1/',
    VPLAY_VISION_TIMEOUT_MS: '1234',
    VPLAY_VISION_MAX_TOKENS: '777',
    VPLAY_TEXT_MODEL: 'text-x',
    VPLAY_TEXT_BASE_URL: 'https://text.example/v1',
    VPLAY_MAX_VISION_CALLS: '3',
    VPLAY_MAX_TEXT_CALLS: '2',
    VPLAY_BROWSER_EXECUTABLE: 'C:/browser.exe',
    DASHSCOPE_API_KEY: 'sk-vision',
    DEEPSEEK_API_KEY: 'sk-text',
  });
  assert.equal(config.vision.model, 'vision-x');
  assert.equal(config.vision.baseUrl, 'https://vision.example/v1');
  assert.equal(config.vision.timeoutMs, 1234);
  assert.equal(config.vision.maxOutputTokens, 777);
  assert.equal(config.text.model, 'text-x');
  assert.equal(config.budget.maxVisionCalls, 3);
  assert.equal(config.budget.maxTextCalls, 2);
  assert.equal(config.browser.executablePath, 'C:/browser.exe');
});

test('api keys stay out of browser config and redactConfig hides them', () => {
  const config = loadConfig({ DASHSCOPE_API_KEY: 'sk-secret', DEEPSEEK_API_KEY: 'sk-secret-2' });
  const redacted = redactConfig(config);
  assert.ok(!JSON.stringify(redacted).includes('sk-secret'));
  assert.ok(!JSON.stringify(config.browser).includes('sk-secret'));
  assert.match(redacted.vision.apiKey, /^<set:\d+>$/);
});

test('assertModelConfig rejects missing keys', () => {
  const config = loadConfig({});
  assert.throws(() => assertModelConfig(config, 'vision'), (error) => error.code === 'CONFIG');
  assert.throws(() => assertModelConfig(config, 'text'), (error) => error.code === 'CONFIG');
});
