import test from 'node:test';
import assert from 'node:assert/strict';
import { createEventSink, EVENT_TYPES, redact } from '../src/events.mjs';

test('event sink emits ordered structured events without storing task state', () => {
  const received = [];
  const sink = createEventSink({
    taskId: 'task_1',
    projectId: 'spacer',
    onEvent: (event) => received.push(event),
    clock: () => '2026-11-26T00:00:00.000Z',
    idFactory: (() => { let n = 0; return () => `evt_${++n}`; })(),
  });
  sink.emit(EVENT_TYPES.TASK_STARTED, { mode: 'analyze' });
  sink.emit(EVENT_TYPES.TASK_COMPLETED, { status: 'analyzed' }, [{ path: 'shot.png', sha256: 'abc' }]);
  assert.equal(received.length, 2);
  assert.equal(received[0].schemaVersion, 1);
  assert.equal(received[0].seq, 1);
  assert.equal(received[1].seq, 2);
  assert.equal(received[1].artifacts[0].path, 'shot.png');
  assert.equal(sink.seq, 2);
});

test('event payload redacts API keys and sk- tokens', () => {
  const sink = createEventSink({ taskId: 't' });
  const event = sink.emit(EVENT_TYPES.ANALYSIS_COMPLETED, {
    apiKey: 'sk-should-not-appear',
    nested: { authorization: 'Bearer x', note: 'sk-abcdefghijklmnopqrstuvwxyz' },
  });
  const text = JSON.stringify(event);
  assert.ok(!text.includes('sk-should-not-appear'));
  assert.ok(!text.includes('Bearer x'));
  assert.ok(text.includes('<redacted>'));
  assert.equal(redact({ token: 'x' }).token, '<redacted>');
});

test('unknown event types are rejected', () => {
  const sink = createEventSink({ taskId: 't' });
  assert.throws(() => sink.emit('vision.unknown', {}), /unknown vision event type/);
});
