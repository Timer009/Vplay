import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';

import {
  describeDelta,
  hashContent,
  materializePatch,
  validatePatchPlan,
} from '../src/index.mjs';
import { tempDir } from './helpers.mjs';

const SOURCE = `<!doctype html><html><head><title>t</title></head>
<body><div id="hud">HUD</div><script>const onChange = () => 1;</script></body></html>`;

test('describeDelta binds digests and returns exact hunks for host delta scanning', async () => {
  const root = await tempDir('delta-');
  const file = path.join(root, 'index.html');
  await fs.writeFile(file, SOURCE, 'utf8');
  const plan = {
    diagnosis: 'safe class',
    patches: [{
      file: 'index.html',
      old_string: '<div id="hud">HUD</div>',
      new_string: '<div id="hud" class="hud-safe">HUD</div>',
      reason: 'visual',
    }],
    verification: ['hud visible'],
  };
  const validation = validatePatchPlan({ plan, root, allowedFiles: ['index.html'] });
  assert.equal(validation.ok, true, validation.errors.join('; '));
  const materialized = materializePatch({ operations: validation.operations, files: validation.files });
  const delta = describeDelta({
    operations: validation.operations,
    files: validation.files,
    materialized: materialized.files,
  });
  const entry = delta.files[0];
  assert.equal(entry.file, 'index.html');
  assert.equal(entry.sha256Before, hashContent(SOURCE));
  assert.equal(entry.sha256After, hashContent(materialized.files[0].content));
  assert.equal(entry.content, materialized.files[0].content);
  assert.equal(entry.hunks.length, 1);
  assert.equal(entry.hunks[0].before, '<div id="hud">HUD</div>');
  assert.equal(entry.hunks[0].after, '<div id="hud" class="hud-safe">HUD</div>');
  assert.ok(entry.hunks[0].start < entry.hunks[0].end);
});

test('describeDelta refuses a materialized content that does not match the operations', async () => {
  const root = await tempDir('delta-mismatch-');
  const file = path.join(root, 'index.html');
  await fs.writeFile(file, SOURCE, 'utf8');
  const plan = {
    diagnosis: 'x',
    patches: [{ file: 'index.html', old_string: 'HUD', new_string: 'HUD2', reason: 'x' }],
    verification: ['x'],
  };
  const validation = validatePatchPlan({ plan, root, allowedFiles: ['index.html'] });
  assert.equal(validation.ok, true);
  const materialized = materializePatch({ operations: validation.operations, files: validation.files });
  const tampered = [{ ...materialized.files[0], sha256After: 'deadbeef' }];
  assert.throws(
    () => describeDelta({ operations: validation.operations, files: validation.files, materialized: tampered }),
    /materialized digest mismatch/,
  );
});
