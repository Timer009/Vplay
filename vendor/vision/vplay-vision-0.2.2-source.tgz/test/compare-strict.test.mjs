import test from 'node:test';
import assert from 'node:assert/strict';

import { compareVerification, defectKeyOf } from '../src/index.mjs';

function capture({ ok, assertions, sha = 'a'.repeat(64) }) {
  return {
    ok,
    viewports: [{
      viewport: 'pc',
      ok,
      sha256: sha,
      assertions: assertions.map(([id, value, critical = true]) => ({ id, ok: value, critical, detail: {} })),
      diagnostics: { pageErrors: [] },
    }],
    screenshots: [{ viewport: 'pc', path: `/tmp/${sha}.png`, sha256: sha, bytes: 1 }],
  };
}

const DEFECT = {
  id: 'V-001',
  defect_type: 'ui_occlusion',
  location: { screen: 'pc', description: 'hud covered', region: { x: 1, y: 2, w: 3, h: 4 } },
};

test('after-only failing assertion is a new critical failure, not persisting', () => {
  const before = capture({ ok: true, assertions: [['hud', true]], sha: 'a'.repeat(64) });
  const after = capture({ ok: false, assertions: [['hud', true], ['newCritical', false]], sha: 'b'.repeat(64) });
  const result = compareVerification({ before, after });
  assert.equal(result.persistingFailures.length, 0);
  assert.equal(result.newFailures.length, 1);
  assert.equal(result.newCriticalFailures.length, 1);
  assert.equal(result.newCriticalFailures[0].id, 'newCritical');
  assert.equal(result.ok, false);
});

test('deleting a before assertion blocks verification and the defect', () => {
  const before = capture({ ok: false, assertions: [['hud', false]], sha: 'a'.repeat(64) });
  const after = capture({ ok: true, assertions: [], sha: 'b'.repeat(64) });
  const result = compareVerification({
    before,
    after,
    defect: DEFECT,
    defectAssertionIds: ['hud'],
  });
  assert.equal(result.missingAssertions.length >= 1, true);
  assert.equal(result.ok, false);
  assert.equal(result.defect.ok, false);
  assert.equal(result.defect.reason, 'defect-assertion-missing');
});

test('defect ids require before-failure and after-pass; screenshots or unrelated failures do not count', () => {
  const beforeFail = capture({ ok: false, assertions: [['hud', false]], sha: 'a'.repeat(64) });
  const afterPass = capture({ ok: true, assertions: [['hud', true]], sha: 'b'.repeat(64) });
  const confirmed = compareVerification({ before: beforeFail, after: afterPass, defect: DEFECT, defectAssertionIds: ['hud'] });
  assert.equal(confirmed.defect.ok, true);
  assert.equal(confirmed.ok, true);

  const beforePass = capture({ ok: true, assertions: [['hud', true]], sha: 'a'.repeat(64) });
  const notReproduced = compareVerification({ before: beforePass, after: afterPass, defect: DEFECT, defectAssertionIds: ['hud'] });
  assert.equal(notReproduced.defect.ok, false);
  assert.equal(notReproduced.defect.reason, 'defect-not-reproduced-before');
  assert.equal(notReproduced.ok, false);

  const screenshotsOnly = compareVerification({ before: beforePass, after: afterPass, defect: DEFECT });
  assert.equal(screenshotsOnly.ok, true, 'without ids the legacy change gate remains');
  assert.equal(screenshotsOnly.defect.ok, false);
  assert.equal(screenshotsOnly.defect.reason, 'no-defect-assertions');
});

test('stable defect key ignores model id and ordering; description changes identity', () => {
  const a = defectKeyOf(DEFECT);
  const b = defectKeyOf({ ...DEFECT, id: 'V-999', location: { ...DEFECT.location, description: 'hud  covered' } });
  const c = defectKeyOf({ ...DEFECT, location: { ...DEFECT.location, description: 'button covered' } });
  assert.equal(a, b);
  assert.notEqual(a, c);
  assert.equal(defectKeyOf({ ...DEFECT, defectKey: 'host-key' }), 'host-key');
});
