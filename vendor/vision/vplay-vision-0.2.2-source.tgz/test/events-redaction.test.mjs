import test from 'node:test';
import assert from 'node:assert/strict';

import { createEventSink, redactObject } from '../src/index.mjs';

test('event sink redacts free-text secrets, env key names and cookies', () => {
  const sink = createEventSink({ taskId: 't', projectId: 'p' });
  const event = sink.emit('vision.task.started', {
    note: 'password = "canary-hunter2-value"',
    env: 'VPLAY_VISION_API_KEY',
    cookie: 'vplay_preview=abcdef0123456789',
    header: 'Cookie: vplay_preview=abcdef0123456789',
    nested: { auth: 'Bearer abcdefghijklmnopqrstuvwxyz' },
    ok: true,
  });
  const serialized = JSON.stringify(event);
  for (const needle of [
    'canary-hunter2-value',
    'VPLAY_VISION_API_KEY',
    'vplay_preview=abcdef0123456789',
    'abcdefghijklmnopqrstuvwxyz',
  ]) {
    assert.equal(serialized.includes(needle), false, `leaked ${needle}`);
  }
  assert.equal(event.payload.cookie, '<redacted>');
  assert.equal(event.payload.ok, true);
});

test('redactObject removes cookie-named fields', () => {
  const result = redactObject({
    cookie: 'vplay_preview=deadbeef',
    headers: { cookie: 'vplay_preview=deadbeef' },
    ok: 'visible',
  });
  assert.equal(result.cookie, '[REDACTED]');
  assert.equal(result.headers, '[REDACTED]');
  assert.equal(result.ok, 'visible');
});
