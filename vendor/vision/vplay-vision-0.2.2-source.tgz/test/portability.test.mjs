import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const src = fileURLToPath(new URL('../src', import.meta.url));

function files(dir) {
  const out = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) out.push(...files(full));
    else if (entry.name.endsWith('.mjs')) out.push(full);
  }
  return out;
}

test('modules do not reference ZCode/Electron or POC absolute paths', () => {
  const forbidden = [/ZCode\.exe/i, /ELECTRON_RUN_AS_NODE/i, /E:[\\/]ZCode/i, /G:[\\/]AI_GAME[\\/]Vplay-Vision-POC/i, /taskkill/i];
  for (const file of files(src)) {
    const text = fs.readFileSync(file, 'utf8');
    for (const pattern of forbidden) {
      assert.ok(!pattern.test(text), `${path.relative(src, file)} contains ${pattern}`);
    }
  }
});

test('patch validator is pure: no writes, snapshots, or rollback implementation', () => {
  const text = fs.readFileSync(path.join(src, 'patch', 'validator.mjs'), 'utf8');
  assert.ok(!/writeFile|mkdtemp|copyFile|rename\(/.test(text));
  assert.ok(!/function\s+snapshot|function\s+rollback|restoreSnapshot/.test(text));
  assert.ok(text.includes('materializePatch'));
});

test('browser runner is isolated from model configuration', () => {
  const text = fs.readFileSync(path.join(src, 'browser', 'runner.mjs'), 'utf8');
  assert.ok(!/from ['"].*config\.mjs/.test(text));
  assert.ok(!/from ['"].*gateway\.mjs/.test(text));
  assert.ok(!/apiKey|DASHSCOPE|DEEPSEEK/.test(text));
  assert.ok(text.includes('sanitizeBrowserEnv'));
});

test('package declares Node >= 20 and optional playwright-core peer', () => {
  const pkg = JSON.parse(fs.readFileSync(new URL('../package.json', import.meta.url), 'utf8'));
  assert.match(pkg.engines.node, />=20/);
  assert.ok(pkg.peerDependencies['playwright-core']);
  assert.equal(pkg.peerDependenciesMeta['playwright-core'].optional, true);
});

test('public entry imports without a browser or model key', async () => {
  const mod = await import('../src/index.mjs');
  for (const name of [
    'loadConfig', 'Budget', 'VisionError', 'analyzeScreenshots', 'proposePatchPlan',
    'validatePatchPlan', 'materializePatch', 'createModelGateway', 'createBrowserRunner',
    'createDomAdapter', 'createSpacerAdapter', 'createEventSink', 'runVisionTask',
  ]) {
    assert.equal(typeof mod[name], 'function', name);
  }
});
