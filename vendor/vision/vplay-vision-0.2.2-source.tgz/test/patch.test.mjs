import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { validatePatchPlan, materializePatch, scriptRanges } from '../src/patch/validator.mjs';
import { tempDir } from './helpers.mjs';

const HTML = `<!doctype html>
<html><head>
<style>#btnT{position:fixed;right:10px;bottom:10px;z-index:10}</style>
<!-- INJECT:START -->
<style>#cover{position:fixed;inset:auto 0 0 auto;z-index:9999}</style>
<div id="cover">STATUS</div>
<!-- INJECT:END -->
</head><body>
<button id="btnT">up</button>
<script>window.game={fuel:120};</script>
</body></html>`;

async function workspace() {
  const dir = await tempDir('e03-patch-');
  await fs.writeFile(path.join(dir, 'index.html'), HTML, 'utf8');
  return dir;
}

test('valid removal validates and materializes without writing', async () => {
  const dir = await workspace();
  try {
    const before = await fs.readFile(path.join(dir, 'index.html'), 'utf8');
    const plan = {
      diagnosis: 'cover hides button',
      patches: [{
        file: 'index.html',
        old_string: '<div id="cover">STATUS</div>',
        new_string: '',
        reason: 'remove cover',
      }],
      verification: ['hit test'],
    };
    const validation = validatePatchPlan({ plan, root: dir, allowedFiles: ['index.html'] });
    assert.equal(validation.ok, true, validation.errors.join('; '));
    const result = materializePatch({ operations: validation.operations, files: validation.files });
    assert.equal(result.files.length, 1);
    assert.ok(!result.files[0].content.includes('<div id="cover">'));
    assert.equal(await fs.readFile(path.join(dir, 'index.html'), 'utf8'), before, 'validator must not write');
  } finally {
    await fs.rm(dir, { recursive: true, force: true });
  }
});

test('script edits, dangerous new content, path traversal and duplicates are rejected', async () => {
  const dir = await workspace();
  try {
    const scriptPlan = {
      diagnosis: 'x',
      patches: [{ file: 'index.html', old_string: 'window.game={fuel:120};', new_string: '', reason: 'x' }],
      verification: ['x'],
    };
    assert.equal(validatePatchPlan({ plan: scriptPlan, root: dir, allowedFiles: ['index.html'] }).ok, false);

    const dangerous = {
      diagnosis: 'x',
      patches: [{ file: 'index.html', old_string: '<div id="cover">STATUS</div>', new_string: '<script>x</script>', reason: 'x' }],
      verification: ['x'],
    };
    const dangerousResult = validatePatchPlan({ plan: dangerous, root: dir, allowedFiles: ['index.html'] });
    assert.equal(dangerousResult.ok, false);
    assert.ok(dangerousResult.errors.some((error) => /script-tag|tag not allowed: script|script/i.test(error)));

    for (const file of ['../index.html', '/etc/passwd', 'other.html']) {
      const plan = {
        diagnosis: 'x',
        patches: [{ file, old_string: '<div id="cover">STATUS</div>', new_string: '', reason: 'x' }],
        verification: ['x'],
      };
      assert.equal(validatePatchPlan({ plan, root: dir, allowedFiles: ['index.html'] }).ok, false, file);
    }

    const duplicate = {
      diagnosis: 'x',
      patches: [{ file: 'index.html', old_string: 'INJECT', new_string: '', reason: 'x' }],
      verification: ['x'],
    };
    const duplicateResult = validatePatchPlan({ plan: duplicate, root: dir, allowedFiles: ['index.html'] });
    assert.equal(duplicateResult.ok, false);
    assert.ok(duplicateResult.errors.some((error) => error.includes('exactly once')));
  } finally {
    await fs.rm(dir, { recursive: true, force: true });
  }
});

test('scriptRanges finds inline scripts', () => {
  const ranges = scriptRanges(HTML);
  assert.equal(ranges.length, 1);
  assert.ok(HTML.slice(ranges[0].start, ranges[0].end).includes('window.game'));
});
