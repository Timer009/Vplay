import test from 'node:test';
import assert from 'node:assert/strict';

import { compareVerification } from '../src/index.mjs';

function capture({ ok, assertions, sha = 'a'.repeat(64) }) {
  return {
    ok,
    viewports: [{
      viewport: 'desktop',
      ok,
      sha256: sha,
      assertions: assertions.map(([id, value, critical = true]) => ({
        id,
        ok: value,
        critical,
        detail: {},
      })),
      diagnostics: { pageErrors: [] },
    }],
    screenshots: [{ viewport: 'desktop', path: `/tmp/${sha}.png`, sha256: sha, bytes: 1 }],
  };
}

test('resolved critical failure confirms a repair', () => {
  const before = capture({ ok: false, assertions: [['action', true], ['hud', false]], sha: 'a'.repeat(64) });
  const after = capture({ ok: true, assertions: [['action', true], ['hud', true]], sha: 'b'.repeat(64) });
  const result = compareVerification({ before, after });
  assert.equal(result.ok, true);
  assert.equal(result.resolvedCriticalFailures.length, 1);
  assert.equal(result.resolvedCriticalFailures[0].id, 'hud');
  assert.equal(result.newCriticalFailures.length, 0);
  assert.equal(result.screenshotsChanged, true);
});

test('new critical failure blocks verification', () => {
  const before = capture({ ok: true, assertions: [['action', true]], sha: 'a'.repeat(64) });
  const after = capture({ ok: false, assertions: [['action', false]], sha: 'b'.repeat(64) });
  const result = compareVerification({ before, after });
  assert.equal(result.ok, false);
  assert.equal(result.newCriticalFailures.length, 1);
  assert.equal(result.newCriticalFailures[0].id, 'action');
});

test('no visible change with both sides passing is not a confirmed repair', () => {
  const before = capture({ ok: true, assertions: [['action', true]], sha: 'a'.repeat(64) });
  const after = capture({ ok: true, assertions: [['action', true]], sha: 'a'.repeat(64) });
  const result = compareVerification({ before, after });
  assert.equal(result.ok, false);
  assert.equal(result.screenshotsChanged, false);
});

test('visual-only fix (changed screenshot, both pass) is confirmed; non-critical regressions are reported', () => {
  const before = capture({
    ok: true,
    assertions: [['action', true], ['hint', true, false]],
    sha: 'a'.repeat(64),
  });
  const after = capture({
    ok: true,
    assertions: [['action', true], ['hint', false, false]],
    sha: 'b'.repeat(64),
  });
  const result = compareVerification({ before, after });
  assert.equal(result.ok, true, 'non-critical regressions do not block after.ok');
  assert.equal(result.newFailures.length, 1);
  assert.equal(result.newCriticalFailures.length, 0);
  assert.equal(result.screenshotsChanged, true);
});

test('persisting and new failures are separated', () => {
  const before = capture({ ok: false, assertions: [['hud', false], ['action', true]], sha: 'a'.repeat(64) });
  const after = capture({ ok: false, assertions: [['hud', false], ['action', true]], sha: 'a'.repeat(64) });
  const result = compareVerification({ before, after });
  assert.equal(result.ok, false);
  assert.equal(result.persistingFailures.length, 1);
  assert.equal(result.newFailures.length, 0);
  assert.equal(result.resolvedFailures.length, 0);
});
