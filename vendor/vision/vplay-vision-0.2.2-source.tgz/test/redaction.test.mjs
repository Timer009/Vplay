import test from 'node:test';
import assert from 'node:assert/strict';
import { redactText, redactSource, scanSensitive, redactObject } from '../src/redaction.mjs';

test('redacts keys, tokens, private keys, internal IPs and email', () => {
  const text = [
    'key=sk-abcdefghijklmnopqrstuvwxyz123456',
    'AKIA1234567890ABCDEF',
    'Authorization: Bearer abcdefghijklmnopqrstuvwxyz123456',
    'password="hunter2hunter2"',
    'host 192.168.1.20',
    'mail foo@example.com',
    'VPLAY_VISION_API_KEY',
    '-----BEGIN PRIVATE KEY-----\nsecret\n-----END PRIVATE KEY-----',
  ].join('\n');
  const findings = scanSensitive(text);
  assert.ok(findings.some((item) => item.type === 'openai-style-key'));
  assert.ok(findings.some((item) => item.type === 'private-key'));
  assert.ok(findings.some((item) => item.type === 'internal-ipv4'));
  const out = redactText(text);
  assert.ok(!out.includes('sk-abcdefghijklmnopqrstuvwxyz123456'));
  assert.ok(!out.includes('hunter2hunter2'));
  assert.ok(!out.includes('192.168.1.20'));
  assert.ok(!out.includes('foo@example.com'));
  assert.ok(!out.includes('BEGIN PRIVATE KEY'));
  assert.match(out, /\[REDACTED:/);
});

test('redactSource caps source and reports findings without values', () => {
  const result = redactSource('x'.repeat(50) + ' sk-abcdefghijklmnopqrstuvwxyz123456', { maxChars: 20 });
  assert.equal(result.truncated, true);
  assert.ok(result.findings.length >= 1);
  assert.ok(!result.text.includes('sk-abcdefghijklmnopqrstuvwxyz123456'));
  assert.match(result.text, /SOURCE_TRUNCATED/);
});

test('redactObject removes secret-named fields and redacts string values', () => {
  const out = redactObject({
    apiKey: 'secret',
    nested: { token: 'x', note: 'sk-abcdefghijklmnopqrstuvwxyz123456' },
  });
  assert.equal(out.apiKey, '[REDACTED]');
  assert.equal(out.nested.token, '[REDACTED]');
  assert.ok(!JSON.stringify(out).includes('sk-abcdefghijklmnopqrstuvwxyz123456'));
});
