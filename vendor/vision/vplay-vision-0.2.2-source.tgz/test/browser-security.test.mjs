import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createBrowserRunner } from '../src/browser/runner.mjs';
import { loadPlaywrightCore } from '../src/browser/runner.mjs';
import { findBrowserExecutable } from '../src/browser/discover.mjs';
import { installNetworkGuard } from '../src/browser/guard.mjs';
import { createDomAdapter } from '../src/verification/adapters/dom.mjs';
import { startStaticServer, startStub, jsonResponse, tempDir } from './helpers.mjs';

const browserPath = findBrowserExecutable({});
const hasBrowser = Boolean(browserPath);

function html(attackOrigin) {
  return `<!doctype html><html><head><meta charset="utf-8">
  <link rel="stylesheet" href="${attackOrigin}/evil.css">
  </head><body><div id="app">
    <div id="secret" style="width:80px;height:40px;background:#f00">SECRET</div>
    <button id="start">Start</button><p id="status">idle</p>
  </div>
  <script>
    fetch('${attackOrigin}/beacon').catch(()=>{});
    const i = new Image(); i.src = '${attackOrigin}/pixel.png';
    window.open('${attackOrigin}/popup', '_blank');
    document.getElementById('start').addEventListener('click', () => {
      document.getElementById('status').textContent = 'started';
    });
  </script></body></html>`;
}

test('browser guard blocks external requests/navigation and records evidence', { skip: !hasBrowser }, async () => {
  const attack = await startStub((req, res) => jsonResponse(res, 200, { ok: true }));
  const attackOrigin = new URL(attack.baseUrl).origin;
  const dir = await tempDir('e05-net-');
  const out = await tempDir('e05-shots-');
  await fs.writeFile(path.join(dir, 'index.html'), html(attackOrigin), 'utf8');
  const server = await startStaticServer(dir);
  try {
    const runner = createBrowserRunner({ executablePath: browserPath });
    const adapter = createDomAdapter({ id: 'net', readySelector: '#app', interactiveSelector: '#start' });
    const result = await runner.runCapture({ url: server.url, adapter, scenario: 'default', outDir: out });
    assert.equal(attack.requests.length, 0, 'external requests must not reach the attacker server');
    assert.equal(result.viewports[0].network.blocked.some((entry) => entry.url.startsWith(attackOrigin)), true);
    assert.equal(result.viewports[0].network.navigationBlocked, 0);
  } finally {
    await server.close();
    await attack.close();
    await fs.rm(dir, { recursive: true, force: true });
    await fs.rm(out, { recursive: true, force: true });
  }
});

test('screenshot redaction masks sensitive selector and changes the image', { skip: !hasBrowser }, async () => {
  const dir = await tempDir('e05-redact-');
  const out = await tempDir('e05-shots-');
  await fs.writeFile(path.join(dir, 'index.html'), `<!doctype html><html><body>
    <div id="app"><div id="secret" style="width:120px;height:60px;background:#f00">SECRET</div>
    <button id="start">Start</button><p id="status">idle</p></div>
    <script>document.getElementById('start').onclick=()=>document.getElementById('status').textContent='started';</script>
  </body></html>`, 'utf8');
  const server = await startStaticServer(dir);
  try {
    const runner = createBrowserRunner({ executablePath: browserPath });
    const base = createDomAdapter({ id: 'redact', readySelector: '#app', interactiveSelector: '#start' });
    const masked = createDomAdapter({
      id: 'redact',
      readySelector: '#app',
      interactiveSelector: '#start',
      redaction: { selectors: ['#secret'] },
    });
    const control = await runner.runCapture({ url: server.url, adapter: base, scenario: 'default', outDir: out, captureId: 'control' });
    const redacted = await runner.runCapture({ url: server.url, adapter: masked, scenario: 'default', outDir: out, captureId: 'masked' });
    assert.equal(control.ok, true, JSON.stringify(control.viewports[0]?.assertions));
    assert.equal(redacted.ok, true, JSON.stringify(redacted.viewports[0]?.assertions));
    assert.equal(redacted.viewports[0].redaction.maskedSelectors, 1);
    assert.notEqual(control.screenshots[0].sha256, redacted.screenshots[0].sha256);
  } finally {
    await server.close();
    await fs.rm(dir, { recursive: true, force: true });
    await fs.rm(out, { recursive: true, force: true });
  }
});

test('guard blocks cross-origin top-level navigation', { skip: !hasBrowser }, async () => {
  const attack = await startStub((req, res) => jsonResponse(res, 200, { ok: true }));
  const attackOrigin = new URL(attack.baseUrl).origin;
  const dir = await tempDir('e05-nav-');
  await fs.writeFile(path.join(dir, 'index.html'), '<!doctype html><html><body><div id="app">ok</div></body></html>', 'utf8');
  const server = await startStaticServer(dir);
  const { chromium } = loadPlaywrightCore();
  const browser = await chromium.launch({ executablePath: browserPath, headless: true });
  try {
    const context = await browser.newContext();
    const guard = await installNetworkGuard({ context, previewUrl: server.url });
    const page = await context.newPage();
    guard.setMainPage(page);
    await page.goto(server.url, { waitUntil: 'load' });
    await page.evaluate((url) => { window.location.href = url; }, attackOrigin + '/nav');
    await page.waitForTimeout(300);
    assert.equal(attack.requests.length, 0);
    assert.ok(guard.summary().navigationBlocked >= 1);
    assert.ok(!page.url().startsWith(attackOrigin));
  } finally {
    await browser.close();
    await server.close();
    await attack.close();
    await fs.rm(dir, { recursive: true, force: true });
  }
});
