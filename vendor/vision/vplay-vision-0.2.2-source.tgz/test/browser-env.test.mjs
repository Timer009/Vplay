import test from 'node:test';
import assert from 'node:assert/strict';
import { sanitizeBrowserEnv, findSecretEnvKeys } from '../src/browser/env.mjs';
import { findBrowserExecutable } from '../src/browser/discover.mjs';

test('browser env strips API keys/tokens and keeps display/library vars', () => {
  const env = {
    PATH: '/usr/bin',
    HOME: '/home/u',
    DISPLAY: ':0',
    LANG: 'zh_CN.UTF-8',
    DASHSCOPE_API_KEY: 'sk-secret',
    DEEPSEEK_API_KEY: 'sk-secret-2',
    OPENAI_API_KEY: 'sk-secret-3',
    GITHUB_TOKEN: 'token',
    AWS_SECRET_ACCESS_KEY: 'secret',
    NODE_OPTIONS: '--inspect',
  };
  const sanitized = sanitizeBrowserEnv(env);
  assert.equal(sanitized.PATH, '/usr/bin');
  assert.equal(sanitized.HOME, '/home/u');
  assert.equal(sanitized.DISPLAY, ':0');
  assert.equal(sanitized.DASHSCOPE_API_KEY, undefined);
  assert.equal(sanitized.DEEPSEEK_API_KEY, undefined);
  assert.equal(sanitized.OPENAI_API_KEY, undefined);
  assert.equal(sanitized.GITHUB_TOKEN, undefined);
  assert.equal(sanitized.AWS_SECRET_ACCESS_KEY, undefined);
  assert.equal(sanitized.NODE_OPTIONS, undefined);
  assert.ok(findSecretEnvKeys(env).includes('DASHSCOPE_API_KEY'));
});

test('browser executable honors explicit env and common platform paths', () => {
  const explicit = findBrowserExecutable({
    env: { VPLAY_BROWSER_EXECUTABLE: '/custom/chrome' },
    platform: 'linux',
    exists: (value) => value === '/custom/chrome',
  });
  assert.equal(explicit, '/custom/chrome');
  const linux = findBrowserExecutable({
    env: {},
    platform: 'linux',
    exists: (value) => value === '/usr/bin/chromium',
  });
  assert.equal(linux, '/usr/bin/chromium');
  const none = findBrowserExecutable({ env: {}, platform: 'linux', exists: () => false });
  assert.equal(none, null);
});
