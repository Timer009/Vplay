import test from 'node:test';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import { parseVisionReport, analyzeScreenshots } from '../src/vision.mjs';
import { Budget } from '../src/budget.mjs';
import { ERROR_CATEGORIES } from '../src/errors.mjs';
import { startStub, jsonResponse, chatReply, readFixture, findSamples } from './helpers.mjs';

const IMAGE = findSamples('images/S01.png');

test('replays the real E02 S03 response offline', () => {
  const report = parseVisionReport({ content: readFixture('vision-s03-raw.txt'), finishReason: 'stop' });
  assert.equal(report.defects.length, 5);
  assert.equal(report.defects[0].defect_type, 'ui_occlusion');
  assert.equal(report.defects[0].severity, 'major');
  assert.equal(report.defects[0].confidence, 0.72);
});

test('replays the real E02 S06 candidate response offline', () => {
  const report = parseVisionReport({ content: readFixture('vision-s06-raw.txt'), finishReason: 'stop' });
  assert.equal(report.defects.length, 3);
  assert.ok(report.defects.some((defect) => defect.defect_type === 'rendering' && defect.confidence === 0.55));
});

test('analyzeScreenshots sends image data URL and records usage', { skip: !IMAGE }, async () => {
  const stub = await startStub((req, res) => jsonResponse(res, 200, chatReply(readFixture('vision-s03-raw.txt'), {
    model: 'qwen4-max',
    usage: { prompt_tokens: 1700, completion_tokens: 3000, total_tokens: 4700 },
  })));
  const budget = new Budget({ maxVisionCalls: 2, maxTextCalls: 1 });
  try {
    const result = await analyzeScreenshots({
      config: {
        model: 'qwen4-max',
        baseUrl: stub.baseUrl,
        apiKey: 'sk-test',
        timeoutMs: 5000,
        maxOutputTokens: 6000,
        structuredOutput: 'prompt',
      },
      images: [IMAGE],
      budget,
      retry: { maxAttempts: 1 },
    });
    assert.equal(result.report.defects.length, 5);
    assert.equal(result.meta.model, 'qwen4-max');
    const request = stub.requests[0].body;
    assert.equal(request.model, 'qwen4-max');
    assert.equal(request.max_tokens, 6000);
    const parts = request.messages[1].content;
    assert.ok(parts.some((part) => part.type === 'image_url' && part.image_url.url.startsWith('data:image/png;base64,')));
    const summary = budget.summary();
    assert.equal(summary.calls.vision, 1);
    assert.equal(summary.usage.vision.total_tokens, 4700);
  } finally {
    await stub.close();
  }
});

test('structured json_object adds response_format', { skip: !IMAGE }, async () => {
  const stub = await startStub((req, res) => jsonResponse(res, 200, chatReply('{"summary":"ok","defects":[],"limitations":["single image"]}')));
  try {
    await analyzeScreenshots({
      config: {
        model: 'qwen4-max', baseUrl: stub.baseUrl, apiKey: 'sk-test',
        timeoutMs: 5000, maxOutputTokens: 6000, structuredOutput: 'json_object',
      },
      images: [IMAGE],
      retry: { maxAttempts: 1 },
    });
    assert.deepEqual(stub.requests[0].body.response_format, { type: 'json_object' });
  } finally {
    await stub.close();
  }
});

test('finish_reason=length is explicit output truncation and counts against budget', { skip: !IMAGE }, async () => {
  const stub = await startStub((req, res) => jsonResponse(res, 200, chatReply('{"summary":"truncated', {
    finishReason: 'length',
    usage: { prompt_tokens: 100, completion_tokens: 6000, total_tokens: 6100 },
  })));
  const budget = new Budget({ maxVisionCalls: 2 });
  try {
    await assert.rejects(
      analyzeScreenshots({
        config: { model: 'qwen4-max', baseUrl: stub.baseUrl, apiKey: 'sk-test', timeoutMs: 5000, maxOutputTokens: 6000 },
        images: [IMAGE],
        budget,
        retry: { maxAttempts: 1 },
      }),
      (error) => error.category === ERROR_CATEGORIES.OUTPUT_TRUNCATED,
    );
    const summary = budget.summary();
    assert.equal(summary.calls.vision, 1);
    assert.equal(summary.usage.vision.total_tokens, 6100);
    assert.equal(summary.events[0].failed, true);
  } finally {
    await stub.close();
  }
});
