import test from 'node:test';
import assert from 'node:assert/strict';
import { postJson, assertModelUrl } from '../src/http.mjs';
import { ERROR_CATEGORIES } from '../src/errors.mjs';
import { startStub, jsonResponse } from './helpers.mjs';

const body = { model: 'm', messages: [{ role: 'user', content: 'x' }] };

test('non-loopback HTTP model endpoint is rejected unless explicitly allowed', () => {
  assert.throws(
    () => assertModelUrl('http://example.com/v1', {}),
    (error) => error.code === 'INSECURE_MODEL_URL',
  );
  assert.equal(assertModelUrl('http://example.com/v1', { VPLAY_ALLOW_INSECURE_MODEL: '1' }).hostname, 'example.com');
  assert.equal(assertModelUrl('https://example.com/v1', {}).protocol, 'https:');
  assert.equal(assertModelUrl('http://127.0.0.1:1234/v1', {}).hostname, '127.0.0.1');
});

test('model host allowlist is enforced when configured', () => {
  assert.throws(
    () => assertModelUrl('https://evil.example/v1', { VPLAY_MODEL_ALLOWED_HOSTS: 'dashscope.aliyuncs.com' }),
    (error) => error.code === 'MODEL_HOST_NOT_ALLOWED',
  );
  assert.equal(assertModelUrl('https://dashscope.aliyuncs.com/v1', { VPLAY_MODEL_ALLOWED_HOSTS: 'dashscope.aliyuncs.com' }).hostname, 'dashscope.aliyuncs.com');
});

test('oversized model response is rejected', async () => {
  const stub = await startStub((req, res) => jsonResponse(res, 200, { ok: true, padding: 'x'.repeat(2000) }));
  try {
    await assert.rejects(
      postJson({
        baseUrl: stub.baseUrl,
        apiKey: 'sk-test',
        body,
        security: { maxResponseBytes: 100 },
        retry: { maxAttempts: 1 },
      }),
      (error) => error.category === ERROR_CATEGORIES.HTTP && error.code === 'RESPONSE_TOO_LARGE',
    );
  } finally {
    await stub.close();
  }
});
