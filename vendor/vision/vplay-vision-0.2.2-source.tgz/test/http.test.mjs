import test from 'node:test';
import assert from 'node:assert/strict';
import { postJson } from '../src/http.mjs';
import { ERROR_CATEGORIES } from '../src/errors.mjs';
import { startStub, jsonResponse, chatReply } from './helpers.mjs';

const body = { model: 'm', messages: [{ role: 'user', content: 'x' }] };

test('success sends bearer auth and returns payload/request id', async () => {
  const stub = await startStub((req, res) => jsonResponse(res, 200, chatReply('ok')));
  try {
    const result = await postJson({
      baseUrl: stub.baseUrl,
      apiKey: 'sk-test',
      body,
      provider: 'qwen',
      retry: { maxAttempts: 1 },
    });
    assert.equal(result.payload.choices[0].message.content, 'ok');
    assert.ok(result.requestId);
    assert.equal(stub.requests[0].headers.authorization, 'Bearer sk-test');
  } finally {
    await stub.close();
  }
});

test('401 is not retried and the key is not leaked', async () => {
  const secret = 'sk-do-not-leak-1234567890';
  const stub = await startStub((req, res) => jsonResponse(res, 401, { error: { message: 'invalid key' } }));
  try {
    await assert.rejects(
      postJson({ baseUrl: stub.baseUrl, apiKey: secret, body, provider: 'qwen', retry: { maxAttempts: 3, backoffMs: 0 } }),
      (error) => {
        assert.equal(error.category, ERROR_CATEGORIES.AUTH);
        assert.equal(error.retryable, false);
        assert.ok(!error.message.includes(secret));
        return true;
      },
    );
    assert.equal(stub.requests.length, 1);
  } finally {
    await stub.close();
  }
});

test('403 is not retried', async () => {
  const stub = await startStub((req, res) => jsonResponse(res, 403, { error: { message: 'model access denied' } }));
  try {
    await assert.rejects(
      postJson({ baseUrl: stub.baseUrl, apiKey: 'sk-x', body, retry: { maxAttempts: 3, backoffMs: 0 } }),
      (error) => error.category === ERROR_CATEGORIES.PERMISSION,
    );
    assert.equal(stub.requests.length, 1);
  } finally {
    await stub.close();
  }
});

test('5xx is retried once within maxAttempts', async () => {
  const stub = await startStub((req, res, count) => {
    if (count === 1) jsonResponse(res, 503, { error: { message: 'busy' } });
    else jsonResponse(res, 200, chatReply('recovered'));
  });
  try {
    const result = await postJson({
      baseUrl: stub.baseUrl,
      apiKey: 'sk-x',
      body,
      retry: { maxAttempts: 2, retryOn5xx: true, backoffMs: 0 },
    });
    assert.equal(result.payload.choices[0].message.content, 'recovered');
    assert.equal(stub.requests.length, 2);
  } finally {
    await stub.close();
  }
});

test('429 quota/rate-limit is not retried by default', async () => {
  const stub = await startStub((req, res) => jsonResponse(res, 429, { error: { code: 'insufficient_quota', message: 'quota exceeded' } }));
  try {
    await assert.rejects(
      postJson({ baseUrl: stub.baseUrl, apiKey: 'sk-x', body, retry: { maxAttempts: 3, backoffMs: 0 } }),
      (error) => error.category === ERROR_CATEGORIES.QUOTA,
    );
    assert.equal(stub.requests.length, 1);
  } finally {
    await stub.close();
  }
});
