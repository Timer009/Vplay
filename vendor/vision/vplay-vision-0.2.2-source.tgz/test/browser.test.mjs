import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createBrowserRunner } from '../src/browser/runner.mjs';
import { findBrowserExecutable } from '../src/browser/discover.mjs';
import { createDomAdapter } from '../src/verification/adapters/dom.mjs';
import { createSpacerAdapter } from '../src/verification/adapters/spacer.mjs';
import { startStaticServer, tempDir, findSamples } from './helpers.mjs';

const browserPath = findBrowserExecutable({});
const hasBrowser = Boolean(browserPath);
const spacerCase = findSamples(path.join('cases', 'S03'));

test('DOM adapter captures and verifies click behavior (non-Spacer game)', { skip: !hasBrowser }, async () => {
  const dir = await tempDir('e03-dom-');
  const out = await tempDir('e03-shots-');
  await fs.copyFile(fileURLToPath(new URL('./fixtures/dom-game.html', import.meta.url)), path.join(dir, 'index.html'));
  const server = await startStaticServer(dir);
  try {
    const runner = createBrowserRunner({ executablePath: browserPath });
    const adapter = createDomAdapter({
      id: 'fixture',
      readySelector: '#app',
      interactiveSelector: '#start',
      expectedTextSelector: '#status',
      expectedText: 'started',
    });
    const result = await runner.runCapture({ url: server.url, adapter, scenario: 'default', outDir: out });
    assert.equal(result.ok, true, JSON.stringify(result.viewports[0]?.assertions));
    assert.equal(result.screenshots.length, 1);
    assert.ok(result.viewports[0].assertions.some((a) => a.id === 'interactive-hit-test' && a.ok));
    assert.ok(!JSON.stringify(result.browserEnvKeys).match(/DASHSCOPE|DEEPSEEK|OPENAI|TOKEN/i));
  } finally {
    await server.close();
    await fs.rm(dir, { recursive: true, force: true });
    await fs.rm(out, { recursive: true, force: true });
  }
});

test('Spacer adapter accepts a display:none overlay (visibility, not DOM absence)', { skip: !hasBrowser || !spacerCase }, async () => {
  const dir = await tempDir('e03-spacer-hidden-');
  const out = await tempDir('e03-shots-');
  await fs.cp(spacerCase, dir, { recursive: true });
  const file = path.join(dir, 'index.html');
  const html = await fs.readFile(file, 'utf8');
  await fs.writeFile(file, html.replace('</head>', '<style>#e02-cover-a{display:none !important}</style></head>'), 'utf8');
  const server = await startStaticServer(dir);
  try {
    const runner = createBrowserRunner({ executablePath: browserPath });
    const adapter = createSpacerAdapter({
      overlaySelector: '#e02-cover-a',
      viewports: [{ name: 'mobile-landscape', width: 844, height: 390, deviceScaleFactor: 2, isMobile: true, hasTouch: true }],
    });
    const result = await runner.runCapture({ url: server.url, adapter, scenario: 'default', outDir: out });
    assert.equal(result.ok, true, JSON.stringify(result.viewports[0]?.assertions));
    const assertions = result.viewports[0].assertions;
    assert.ok(assertions.some((a) => a.id === 'overlay-not-visible' && a.ok));
    assert.ok(assertions.some((a) => a.id === 'button-hit-test' && a.ok));
    assert.ok(assertions.some((a) => a.id === 'touch-thrust' && a.ok));
  } finally {
    await server.close();
    await fs.rm(dir, { recursive: true, force: true });
    await fs.rm(out, { recursive: true, force: true });
  }
});

test('Spacer adapter rejects a visible blocking overlay', { skip: !hasBrowser || !spacerCase }, async () => {
  const dir = await tempDir('e03-spacer-bad-');
  const out = await tempDir('e03-shots-');
  await fs.cp(spacerCase, dir, { recursive: true });
  const server = await startStaticServer(dir);
  try {
    const runner = createBrowserRunner({ executablePath: browserPath });
    const adapter = createSpacerAdapter({
      overlaySelector: '#e02-cover-a',
      viewports: [{ name: 'mobile-landscape', width: 844, height: 390, deviceScaleFactor: 2, isMobile: true, hasTouch: true }],
    });
    const result = await runner.runCapture({ url: server.url, adapter, scenario: 'default', outDir: out });
    assert.equal(result.ok, false);
    const assertions = result.viewports[0].assertions;
    assert.ok(assertions.some((a) => a.id === 'overlay-not-visible' && !a.ok));
    assert.ok(assertions.some((a) => a.id === 'button-hit-test' && !a.ok));
  } finally {
    await server.close();
    await fs.rm(dir, { recursive: true, force: true });
    await fs.rm(out, { recursive: true, force: true });
  }
});
