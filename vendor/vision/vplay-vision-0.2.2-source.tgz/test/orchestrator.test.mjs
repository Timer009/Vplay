import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { parseVisionReport } from '../src/vision.mjs';
import { runVisionTask } from '../src/orchestrator.mjs';
import { createEventSink, EVENT_TYPES } from '../src/events.mjs';
import { readFixture, tempDir } from './helpers.mjs';

const report = parseVisionReport({ content: readFixture('vision-s03-raw.txt'), finishReason: 'stop' });
const patchPlan = JSON.parse(readFixture('patch-round2.json')).plan;

async function workspace() {
  const dir = await tempDir('e03-orch-');
  const old = patchPlan.patches[0].old_string;
  await fs.writeFile(
    path.join(dir, 'index.html'),
    `<!doctype html><html><head>${old}</head><body><button id="btnT">up</button><script>window.game={fuel:120};</script></body></html>`,
    'utf8',
  );
  return dir;
}

function fakeBrowser({ afterOk = true } = {}) {
  const calls = [];
  return {
    calls,
    async runCapture({ scenario }) {
      calls.push(scenario);
      const ok = scenario === 'after' ? afterOk : false;
      return {
        ok,
        browserVersion: 'fake',
        durationMs: 1,
        screenshots: [{ path: `/tmp/${scenario}.png`, viewport: 'pc', sha256: 'a'.repeat(64), bytes: 10 }],
        viewports: [{
          viewport: 'pc',
          ok,
          assertions: ok ? [{ id: 'state', ok: true, critical: true, detail: {} }] : [{ id: 'state', ok: false, critical: true, detail: {} }],
          diagnostics: { pageErrors: [], console: [], requestFailures: [] },
        }],
      };
    },
  };
}

function fakeGateway() {
  return {
    async analyzeScreenshots() {
      return { report, meta: { model: 'qwen4-max', usage: { total_tokens: 100 }, latencyMs: 5, requestId: 'r1' } };
    },
    async proposePatchPlan() {
      return { plan: patchPlan, meta: { model: 'deepseek-flash', usage: { total_tokens: 50 }, latencyMs: 3, requestId: 'r2' } };
    },
    summary() {
      return { calls: { vision: 1, text: 1 }, usage: { vision: { total_tokens: 100 }, text: { total_tokens: 50 } } };
    },
  };
}

function fakeHost() {
  const calls = { snapshot: [], apply: [], diff: [], rollback: [] };
  return {
    calls,
    async snapshot(label) { calls.snapshot.push(label); return { seq: 7 }; },
    async applyFiles(files) { calls.apply.push(files.map((file) => file.file)); },
    async diff(seq) { calls.diff.push(seq); return { counts: { added: 0, modified: 1, removed: 0 }, files: [{ path: 'index.html', status: 'modified' }] }; },
    async rollback(seq) { calls.rollback.push(seq); },
  };
}

test('repair mode drives host snapshot/apply/diff and succeeds without owning state', async () => {
  const root = await workspace();
  const outDir = await tempDir('e03-out-');
  const host = fakeHost();
  const browser = fakeBrowser({ afterOk: true });
  const events = createEventSink({ taskId: 'task_1', projectId: 'spacer' });
  try {
    const result = await runVisionTask({
      taskId: 'task_1',
      projectId: 'spacer',
      root,
      previewUrl: 'http://127.0.0.1:1/',
      adapter: { id: 'fake', viewports: [{ name: 'pc' }] },
      browserRunner: browser,
      gateway: fakeGateway(),
      host,
      events,
      mode: 'repair',
      sourceProvider: async () => '1: <div id="cover"></div>',
      allowedFiles: ['index.html'],
      outDir,
    });
    assert.equal(result.ok, true, JSON.stringify(result.error || result.status));
    assert.equal(result.status, 'repaired');
    assert.deepEqual(host.calls.snapshot.length, 1);
    assert.equal(host.calls.apply.length, 1);
    assert.deepEqual(host.calls.diff, [7]);
    assert.equal(host.calls.rollback.length, 0);
    assert.ok(events.events.some((event) => event.type === EVENT_TYPES.SNAPSHOT_CREATED));
    assert.ok(events.events.some((event) => event.type === EVENT_TYPES.PATCH_APPLIED));
    assert.ok(events.events.some((event) => event.type === EVENT_TYPES.VERIFICATION_COMPLETED));
    assert.ok(events.events.some((event) => event.type === EVENT_TYPES.TASK_COMPLETED));
    assert.ok(!JSON.stringify(events.events).includes('sk-'));
  } finally {
    await fs.rm(root, { recursive: true, force: true });
    await fs.rm(outDir, { recursive: true, force: true });
  }
});

test('failed functional verification calls host rollback', async () => {
  const root = await workspace();
  const outDir = await tempDir('e03-out-');
  const host = fakeHost();
  const events = createEventSink({ taskId: 'task_2' });
  try {
    const result = await runVisionTask({
      taskId: 'task_2',
      root,
      previewUrl: 'http://127.0.0.1:1/',
      adapter: { id: 'fake', viewports: [{ name: 'pc' }] },
      browserRunner: fakeBrowser({ afterOk: false }),
      gateway: fakeGateway(),
      host,
      events,
      mode: 'repair',
      sourceProvider: async () => 'source',
      allowedFiles: ['index.html'],
      maxRepairRounds: 1,
      outDir,
    });
    assert.equal(result.ok, false);
    assert.equal(result.status, 'repair_failed');
    assert.deepEqual(host.calls.rollback, [7]);
    assert.ok(events.events.some((event) => event.type === EVENT_TYPES.ROLLBACK_COMPLETED));
    assert.ok(events.events.some((event) => event.type === EVENT_TYPES.TASK_FAILED));
  } finally {
    await fs.rm(root, { recursive: true, force: true });
    await fs.rm(outDir, { recursive: true, force: true });
  }
});

test('analyze mode needs no host and emits a report', async () => {
  const outDir = await tempDir('e03-out-');
  const events = createEventSink({ taskId: 'task_3' });
  try {
    const result = await runVisionTask({
      taskId: 'task_3',
      previewUrl: 'http://127.0.0.1:1/',
      adapter: { id: 'fake', viewports: [{ name: 'pc' }] },
      browserRunner: fakeBrowser({ afterOk: true }),
      gateway: fakeGateway(),
      events,
      mode: 'analyze',
      outDir,
    });
    assert.equal(result.ok, true);
    assert.equal(result.status, 'analyzed');
    assert.equal(result.report.defects.length, 5);
    assert.ok(events.events.some((event) => event.type === EVENT_TYPES.ANALYSIS_COMPLETED));
  } finally {
    await fs.rm(outDir, { recursive: true, force: true });
  }
});

test('unexpected browser failure after apply still triggers host rollback', async () => {
  const root = await workspace();
  const outDir = await tempDir('e03-out-');
  const host = fakeHost();
  const browser = {
    calls: [],
    async runCapture({ scenario }) {
      if (scenario === 'after') throw new Error('browser crashed');
      return {
        ok: false,
        browserVersion: 'fake',
        durationMs: 1,
        screenshots: [{ path: '/tmp/before.png', viewport: 'pc', sha256: 'a'.repeat(64), bytes: 10 }],
        viewports: [{ viewport: 'pc', ok: false, assertions: [], diagnostics: { pageErrors: [], console: [], requestFailures: [] } }],
      };
    },
  };
  try {
    const result = await runVisionTask({
      taskId: 'task_4',
      root,
      previewUrl: 'http://127.0.0.1:1/',
      adapter: { id: 'fake', viewports: [{ name: 'pc' }] },
      browserRunner: browser,
      gateway: fakeGateway(),
      host,
      mode: 'repair',
      sourceProvider: async () => 'source',
      allowedFiles: ['index.html'],
      maxRepairRounds: 1,
      outDir,
    });
    assert.equal(result.ok, false);
    assert.deepEqual(host.calls.rollback, [7]);
    assert.equal(result.rollback.ok, true);
  } finally {
    await fs.rm(root, { recursive: true, force: true });
    await fs.rm(outDir, { recursive: true, force: true });
  }
});
