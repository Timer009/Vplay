import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

import {
  validatePatchPlan,
  validateStructureDelta,
  changedRangesFromOperations,
  normalizeStructural,
  structuralFindings,
} from '../src/index.mjs';
import { tempDir } from './helpers.mjs';

async function sourceFile(html) {
  const dir = await tempDir('e10-structure-');
  fs.writeFileSync(path.join(dir, 'index.html'), html, 'utf8');
  return dir;
}

function planFor(file, oldString, newString) {
  return {
    diagnosis: 'x',
    patches: [{ file: 'index.html', old_string: oldString, new_string: newString, reason: 'x' }],
    verification: ['x'],
  };
}

test('normalized structural scan catches cross-line script and javascript scheme', () => {
  assert.deepEqual(structuralFindings('<scr\nipt>alert(1)</script>'), ['script-tag', 'script-close']);
  assert.deepEqual(structuralFindings('java\nscript:alert(1)'), ['javascript-url']);
  assert.deepEqual(structuralFindings('java&#x0a;script:alert(1)'), ['javascript-url']);
  assert.equal(normalizeStructural('< d i v >').includes('<div>'), true);
  assert.deepEqual(structuralFindings('<div class="safe">text</div>'), []);
});

test('deleting a comment closer or a style closer is rejected', async () => {
  const commentDir = await sourceFile('<!-- safe -->\n<div id="app">ok</div>\n');
  const comment = validatePatchPlan({
    plan: planFor('index.html', '-->', '<div id="safe">x</div>'),
    root: commentDir,
    allowedFiles: ['index.html'],
  });
  assert.equal(comment.ok, false);
  assert.ok(comment.errors.some((item) => item.includes('unclosed-comment')));

  const styleDir = await sourceFile('<style>#app{color:red}</style>\n<div id="app">ok</div>\n');
  const style = validatePatchPlan({
    plan: planFor('index.html', '</style>', '<div id="safe">x</div>'),
    root: styleDir,
    allowedFiles: ['index.html'],
  });
  assert.equal(style.ok, false);
  assert.ok(style.errors.some((item) => item.includes('unclosed-style')));
});

test('removing a complete balanced style block remains legal', async () => {
  const dir = await sourceFile('<style>#app{color:red}</style>\n<div id="app">ok</div>\n');
  const result = validatePatchPlan({
    plan: planFor('index.html', '<style>#app{color:red}</style>', '<div id="safe">ok</div>'),
    root: dir,
    allowedFiles: ['index.html'],
  });
  assert.equal(result.ok, true, result.errors.join('; '));
});

test('legitimate patch next to a baseline script src is not rejected (C12-P1-06)', async () => {
  const dir = await sourceFile('<script src="app.js"></script>\n<h1 id="gameTitle">VECTOR LANDER</h1>\n');
  const result = validatePatchPlan({
    plan: planFor('index.html', '<h1 id="gameTitle">VECTOR LANDER</h1>', '<h1 id="gameTitle" class="safe">VECTOR LANDER</h1>'),
    root: dir,
    allowedFiles: ['index.html'],
  });
  assert.equal(result.ok, true, result.errors.join('; '));
  assert.equal(result.structure[0].ok, true);
});

test('changed-tag scan catches baseline + added line context assembly', () => {
  const before = '<div id="app">ok</div>\n<img\nsrc=\n</body>\n';
  const after = '<div id="app">ok</div>\n<img\nsrc=\n//evil.example/x>\n</body>\n';
  const start = before.indexOf('</body>');
  const operation = {
    file: 'game.html',
    start,
    end: start + 7,
    oldString: '</body>',
    newString: '//evil.example/x>\n</body>',
  };
  const check = validateStructureDelta({
    before,
    after,
    changedRanges: changedRangesFromOperations([operation]),
  });
  assert.equal(check.ok, false);
  assert.ok(check.violations.some((item) => item.code === 'tag-structural'));
});

test('CSS changed region rejects executable constructs', async () => {
  const dir = await sourceFile('<style>#app{color:red}</style>\n<div id="app">ok</div>\n');
  const result = validatePatchPlan({
    plan: planFor('index.html', 'color:red', 'background:url(//evil)'),
    root: dir,
    allowedFiles: ['index.html'],
  });
  assert.equal(result.ok, false);
  assert.ok(result.errors.some((item) => item.includes('url()')));
});
