import test from 'node:test';
import assert from 'node:assert/strict';
import { parsePatchPlan, proposePatchPlan } from '../src/text.mjs';
import { Budget } from '../src/budget.mjs';
import { ERROR_CATEGORIES } from '../src/errors.mjs';
import { startStub, jsonResponse, chatReply, readFixture } from './helpers.mjs';

const fixture = JSON.parse(readFixture('patch-round2.json'));
const report = {
  summary: 'panel covers button',
  defects: [{ defect_type: 'ui_occlusion', confidence: 0.72, location: { description: 'button covered' } }],
  limitations: ['single frame'],
};

test('replays the real E02 DeepSeek patch plan offline', () => {
  const plan = parsePatchPlan({
    content: JSON.stringify(fixture.plan),
    finishReason: 'stop',
    allowedFiles: ['index.html'],
  });
  assert.equal(plan.patches.length, 1);
  assert.equal(plan.patches[0].file, 'index.html');
  assert.equal(plan.patches[0].new_string, '');
  assert.ok(plan.patches[0].old_string.includes('E02-SAMPLE-INJECTION'));
});

test('proposePatchPlan sends text-only messages and records usage', async () => {
  const stub = await startStub((req, res) => jsonResponse(res, 200, chatReply(JSON.stringify(fixture.plan), {
    model: 'deepseek-flash',
    usage: { prompt_tokens: 4000, completion_tokens: 1000, total_tokens: 5000 },
  })));
  const budget = new Budget({ maxVisionCalls: 1, maxTextCalls: 2 });
  try {
    const result = await proposePatchPlan({
      config: {
        model: 'deepseek-v4-flash',
        baseUrl: stub.baseUrl,
        apiKey: 'sk-test',
        timeoutMs: 5000,
        maxOutputTokens: 4096,
      },
      report,
      sourceContext: '1: <div id="x"></div>',
      allowedFiles: ['index.html'],
      budget,
      retry: { maxAttempts: 1 },
    });
    assert.equal(result.plan.patches.length, 1);
    assert.equal(typeof stub.requests[0].body.messages[1].content, 'string');
    const summary = budget.summary();
    assert.equal(summary.calls.text, 1);
    assert.equal(summary.usage.text.total_tokens, 5000);
  } finally {
    await stub.close();
  }
});

test('truncated patch output is explicitly categorized', async () => {
  const stub = await startStub((req, res) => jsonResponse(res, 200, chatReply('{"diagnosis":"x","patches":[', {
    finishReason: 'length',
    usage: { prompt_tokens: 100, completion_tokens: 4096, total_tokens: 4196 },
  })));
  try {
    await assert.rejects(
      proposePatchPlan({
        config: { model: 'deepseek-v4-flash', baseUrl: stub.baseUrl, apiKey: 'sk-test', timeoutMs: 5000, maxOutputTokens: 4096 },
        report,
        sourceContext: 'x',
        allowedFiles: ['index.html'],
        retry: { maxAttempts: 1 },
      }),
      (error) => error.category === ERROR_CATEGORIES.OUTPUT_TRUNCATED,
    );
  } finally {
    await stub.close();
  }
});
