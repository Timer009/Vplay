import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';

import { createBrowserRunner, createDomAdapter } from '../src/index.mjs';
import { findBrowserExecutable } from '../src/browser/discover.mjs';
import { tempDir } from './helpers.mjs';

const browserPath = findBrowserExecutable({});
const hasBrowser = Boolean(browserPath);
const VIEWPORTS = [{ name: 'desktop', width: 700, height: 500, deviceScaleFactor: 1 }];

function listen(server) {
  return new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(0, '127.0.0.1', () => resolve(server.address().port));
  });
}

function pageHtml(label) {
  return `<!doctype html><html><body><div id="app">${label}</div><button id="action">go</button></body></html>`;
}

async function startServer(routes) {
  const hits = [];
  const server = http.createServer((req, res) => {
    hits.push(req.url);
    const handler = routes[req.url] || routes[req.url.split('?')[0]];
    if (handler) { handler(req, res); return; }
    res.writeHead(404); res.end('not found');
  });
  const port = await listen(server);
  return {
    origin: `http://127.0.0.1:${port}`,
    hits,
    close: () => new Promise((resolve) => server.close(() => resolve())),
  };
}

function adapter() {
  return createDomAdapter({
    id: 'redirect',
    viewports: VIEWPORTS,
    readySelector: '#app',
    interactiveSelector: '#action',
    expectedHitId: 'action',
  });
}

test('cross-origin 302 is stopped at the request boundary (CDP Fetch)', { skip: !hasBrowser }, async (t) => {
  const attackerHits = [];
  const attacker = http.createServer((req, res) => {
    attackerHits.push(req.url);
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.end(pageHtml('attacker'));
  });
  const attackerPort = await listen(attacker);
  t.after(() => new Promise((resolve) => attacker.close(() => resolve())));

  const server = await startServer({
    '/p/demo/ext': (req, res) => {
      res.writeHead(302, { Location: `http://127.0.0.1:${attackerPort}/landing` });
      res.end();
    },
  });
  t.after(() => server.close());
  const runner = createBrowserRunner({ executablePath: browserPath, headless: true });
  await assert.rejects(
    () => runner.runCapture({
      url: `${server.origin}/p/demo/ext`,
      adapter: adapter(),
      outDir: 'G:/AI_GAME/Vplay-Vision-POC/e10/artifacts/redirect',
      captureId: 'ext',
    }),
    (error) => {
      assert.equal(error.code, 'REDIRECT_OUT_OF_SCOPE');
      return true;
    },
  );
  assert.equal(attackerHits.length, 0, 'redirect target must never reach the network');
});

test('same-origin redirect outside the preview path is rejected before assertions', { skip: !hasBrowser }, async (t) => {
  const server = await startServer({
    '/p/demo/start': (req, res) => {
      res.writeHead(302, { Location: '/p/other/target' });
      res.end();
    },
    '/p/other/target': (req, res) => {
      res.writeHead(200, { 'Content-Type': 'text/html' });
      res.end(pageHtml('other'));
    },
  });
  t.after(() => server.close());
  const runner = createBrowserRunner({ executablePath: browserPath, headless: true });
  await assert.rejects(
    () => runner.runCapture({
      url: `${server.origin}/p/demo/start`,
      adapter: adapter(),
      outDir: 'G:/AI_GAME/Vplay-Vision-POC/e10/artifacts/redirect',
      captureId: 'path',
    }),
    (error) => error.code === 'NAVIGATION_OUT_OF_SCOPE',
  );
});

test('same-origin redirect inside the preview path works', { skip: !hasBrowser }, async (t) => {
  const server = await startServer({
    '/p/demo/': (req, res) => {
      res.writeHead(302, { Location: '/p/demo/target' });
      res.end();
    },
    '/p/demo/target': (req, res) => {
      res.writeHead(200, { 'Content-Type': 'text/html' });
      res.end(pageHtml('target'));
    },
  });
  t.after(() => server.close());
  const runner = createBrowserRunner({ executablePath: browserPath, headless: true });
  const capture = await runner.runCapture({
    url: `${server.origin}/p/demo/`,
    adapter: adapter(),
    outDir: 'G:/AI_GAME/Vplay-Vision-POC/e10/artifacts/redirect',
    captureId: 'inside',
  });
  assert.equal(capture.ok, true);
  assert.equal(capture.viewports[0].network.previewPath, '/p/demo/');
});
