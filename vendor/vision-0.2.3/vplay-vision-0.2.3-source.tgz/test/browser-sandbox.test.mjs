import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createBrowserRunner } from '../src/browser/runner.mjs';

const runnerSource = fs.readFileSync(
  path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'src', 'browser', 'runner.mjs'),
  'utf8',
);

test('0.2.3 rejects sandbox-disabling launchArgs before browser launch', () => {
  for (const args of [
    ['--no-sandbox'],
    ['--no-sandbox=true'],
    ['--disable-setuid-sandbox'],
    ['--disable-gpu-sandbox'],
    ['--disable-seccomp-filter-sandbox'],
    ['--single-process'],
    ['--no-zygote'],
  ]) {
    assert.throws(
      () => createBrowserRunner({ executablePath: 'unused', launchArgs: args }),
      (error) => error.code === 'BROWSER_SANDBOX_BYPASS',
      args.join(' '),
    );
  }
  assert.throws(
    () => createBrowserRunner({ executablePath: 'unused', launchArgs: '--no-sandbox' }),
    (error) => error.code === 'BROWSER_SANDBOX_BYPASS',
  );
});

test('0.2.3 rejects sandbox-disabling environment input', () => {
  for (const env of [
    { VPLAY_DISABLE_SANDBOX: '1' },
    { VPLAY_BROWSER_ARGS: '--no-sandbox' },
    { PLAYWRIGHT_CHROMIUM_ARGS: '--disable-setuid-sandbox' },
    { CHROMIUM_FLAGS: '--no-sandbox' },
    { CHROME_FLAGS: '--single-process' },
  ]) {
    assert.throws(
      () => createBrowserRunner({ executablePath: 'unused', env }),
      (error) => error.code === 'BROWSER_SANDBOX_BYPASS',
      JSON.stringify(Object.keys(env)),
    );
  }
});

test('0.2.3 source hardcodes chromiumSandbox and has no fallback launch', () => {
  assert.match(runnerSource, /chromiumSandbox:\s*true/);
  assert.match(runnerSource, /args:\s*safeLaunchArgs/);
  assert.doesNotMatch(runnerSource, /chromiumSandbox:\s*false/);
  assert.doesNotMatch(runnerSource, /retry.*no-sandbox|no-sandbox.*retry/i);
});
